"use client"

import { useState } from "react"
import type { ClassRow } from "@/lib/db"
import AutoTextarea from "./auto-textarea"
import { X, Pencil, Trash2, Clock, BookOpen, ClipboardList, Check } from "lucide-react"

type Props = {
  cls: ClassRow
  onClose: () => void
  onUpdate: (id: number, payload: Partial<ClassRow>) => Promise<ClassRow>
  onDelete: (id: number) => Promise<void>
}

const LANGUAGES = ["English", "Spanish", "French", "German", "Italian", "Portuguese", "Japanese", "Mandarin", "Korean", "Arabic", "Russian", "Other"]

function formatTime(t: string) {
  const [h, m] = t.split(":")
  const hour = parseInt(h)
  const ampm = hour >= 12 ? "PM" : "AM"
  const h12  = hour % 12 === 0 ? 12 : hour % 12
  return `${h12}:${m} ${ampm}`
}

function formatDate(d: string) {
  return new Date(d + "T12:00:00").toLocaleDateString("en-US", {
    weekday: "long", year: "numeric", month: "long", day: "numeric",
  })
}

export default function ClassDetailPanel({ cls, onClose, onUpdate, onDelete }: Props) {
  const [editing, setEditing] = useState(false)
  const [saving, setSaving] = useState(false)
  const [confirmDelete, setConfirmDelete] = useState(false)

  const [draft, setDraft] = useState({
    title: cls.title,
    language: cls.language,
    teacher: cls.teacher,
    date: cls.date,
    start_time: cls.start_time,
    end_time: cls.end_time,
    lesson_notes: cls.lesson_notes,
    homework: cls.homework,
  })

  const handleSave = async () => {
    setSaving(true)
    await onUpdate(cls.id, draft)
    setSaving(false)
    setEditing(false)
  }

  const handleDelete = async () => {
    await onDelete(cls.id)
    onClose()
  }

  const current = editing ? draft : cls

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4 bg-foreground/40 backdrop-blur-sm" onClick={onClose}>
      <div
        className="relative w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-2xl bg-card shadow-2xl border border-border flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-start gap-3 p-6 pb-4 border-b border-border sticky top-0 bg-card rounded-t-2xl z-10">
          <div className="flex-1 min-w-0">
            {editing ? (
              <input
                className="w-full text-xl font-bold text-foreground bg-transparent border-b-2 border-primary focus:outline-none pb-1"
                value={draft.title}
                onChange={(e) => setDraft({ ...draft, title: e.target.value })}
              />
            ) : (
              <h2 className="text-xl font-bold text-foreground text-balance">{cls.title}</h2>
            )}
            <div className="flex flex-wrap gap-3 mt-2 text-sm text-muted-foreground">
              <span className="inline-flex items-center gap-1">
                <Clock size={13} />
                {editing ? (
                  <span className="flex gap-1 items-center">
                    <input type="time" value={draft.start_time} onChange={(e) => setDraft({ ...draft, start_time: e.target.value })}
                      className="border border-border rounded px-1 py-0.5 text-xs bg-background text-foreground focus:outline-none focus:ring-1 focus:ring-ring" />
                    <span>–</span>
                    <input type="time" value={draft.end_time} onChange={(e) => setDraft({ ...draft, end_time: e.target.value })}
                      className="border border-border rounded px-1 py-0.5 text-xs bg-background text-foreground focus:outline-none focus:ring-1 focus:ring-ring" />
                  </span>
                ) : (
                  <span>{formatTime(cls.start_time)} – {formatTime(cls.end_time)}</span>
                )}
              </span>
              <span>
                {editing ? (
                  <input type="date" value={draft.date} onChange={(e) => setDraft({ ...draft, date: e.target.value })}
                    className="border border-border rounded px-1 py-0.5 text-xs bg-background text-foreground focus:outline-none focus:ring-1 focus:ring-ring" />
                ) : formatDate(cls.date)}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {editing ? (
              <button onClick={handleSave} disabled={saving}
                className="flex items-center gap-1.5 text-sm px-3 py-1.5 rounded-lg bg-primary text-primary-foreground hover:opacity-90 transition font-medium disabled:opacity-60">
                <Check size={14} /> {saving ? "Saving…" : "Save"}
              </button>
            ) : (
              <button onClick={() => setEditing(true)}
                className="flex items-center gap-1.5 text-sm px-3 py-1.5 rounded-lg bg-secondary text-secondary-foreground hover:bg-brand-light transition font-medium">
                <Pencil size={14} /> Edit
              </button>
            )}
            {confirmDelete ? (
              <button onClick={handleDelete}
                className="flex items-center gap-1.5 text-sm px-3 py-1.5 rounded-lg bg-destructive text-destructive-foreground hover:opacity-90 transition font-medium">
                <Trash2 size={14} /> Confirm
              </button>
            ) : (
              <button onClick={() => setConfirmDelete(true)}
                className="p-2 rounded-lg text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition">
                <Trash2 size={16} />
              </button>
            )}
            <button onClick={onClose}
              className="p-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-muted transition">
              <X size={16} />
            </button>
          </div>
        </div>

        {/* Meta row */}
        <div className="flex flex-wrap gap-4 px-6 pt-4 pb-2">
          <div className="flex flex-col gap-0.5">
            <span className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Language</span>
            {editing ? (
              <select value={draft.language} onChange={(e) => setDraft({ ...draft, language: e.target.value })}
                className="border border-border rounded-lg px-2 py-1 text-sm bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-ring">
                {LANGUAGES.map((l) => <option key={l}>{l}</option>)}
              </select>
            ) : (
              <span className="inline-block bg-brand-light text-primary text-sm font-semibold px-2.5 py-0.5 rounded-full">{cls.language}</span>
            )}
          </div>
          <div className="flex flex-col gap-0.5">
            <span className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Teacher</span>
            {editing ? (
              <input value={draft.teacher} onChange={(e) => setDraft({ ...draft, teacher: e.target.value })}
                className="border border-border rounded-lg px-2 py-1 text-sm bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-ring" />
            ) : (
              <span className="text-sm font-medium text-foreground">{cls.teacher}</span>
            )}
          </div>
        </div>

        {/* Notes & Homework */}
        <div className="px-6 py-4 flex flex-col gap-5">
          <section>
            <h3 className="flex items-center gap-2 text-sm font-bold uppercase tracking-wide text-muted-foreground mb-2">
              <BookOpen size={14} className="text-primary" />
              Lesson Notes
            </h3>
            {editing ? (
              <AutoTextarea
                value={draft.lesson_notes}
                onChange={(v) => setDraft({ ...draft, lesson_notes: v })}
                placeholder="What was covered in this class…"
                minRows={4}
              />
            ) : (
              <div className="text-sm text-foreground leading-relaxed whitespace-pre-wrap rounded-xl bg-secondary p-4 min-h-[80px]">
                {cls.lesson_notes || <span className="text-muted-foreground italic">No lesson notes yet.</span>}
              </div>
            )}
          </section>

          <section>
            <h3 className="flex items-center gap-2 text-sm font-bold uppercase tracking-wide text-muted-foreground mb-2">
              <ClipboardList size={14} className="text-accent-foreground" style={{ color: "var(--accent)" }} />
              Homework
            </h3>
            {editing ? (
              <AutoTextarea
                value={draft.homework}
                onChange={(v) => setDraft({ ...draft, homework: v })}
                placeholder="Assignments and exercises for students…"
                minRows={3}
              />
            ) : (
              <div className="text-sm text-foreground leading-relaxed whitespace-pre-wrap rounded-xl bg-secondary p-4 min-h-[60px]">
                {cls.homework || <span className="text-muted-foreground italic">No homework assigned.</span>}
              </div>
            )}
          </section>
        </div>
      </div>
    </div>
  )
}
