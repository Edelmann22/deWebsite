"use client"

import { ChevronLeft, ChevronRight, Plus } from "lucide-react"
import type { ClassRow } from "@/lib/db"

const MONTH_NAMES = ["January","February","March","April","May","June","July","August","September","October","November","December"]
const DAY_NAMES   = ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"]

function toLocalDateStr(year: number, month: number, day: number) {
  return `${year}-${String(month + 1).padStart(2,"0")}-${String(day).padStart(2,"0")}`
}

type Props = {
  year: number
  month: number
  classes: ClassRow[]
  onPrev: () => void
  onNext: () => void
  onDayClick: (dateStr: string) => void
  onClassClick: (cls: ClassRow) => void
}

export default function CalendarGrid({ year, month, classes, onPrev, onNext, onDayClick, onClassClick }: Props) {
  const today = new Date()
  const todayStr = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2,"0")}-${String(today.getDate()).padStart(2,"0")}`

  const firstDay  = new Date(year, month, 1).getDay()
  const daysInMonth = new Date(year, month + 1, 0).getDate()

  const classMap: Record<string, ClassRow[]> = {}
  for (const c of classes) {
    const key = c.date.slice(0,10)
    if (!classMap[key]) classMap[key] = []
    classMap[key].push(c)
  }

  const cells: (number | null)[] = [
    ...Array(firstDay).fill(null),
    ...Array.from({ length: daysInMonth }, (_, i) => i + 1),
  ]

  // pad to full rows
  while (cells.length % 7 !== 0) cells.push(null)

  return (
    <div className="flex flex-col gap-0">
      {/* Month navigation */}
      <div className="flex items-center justify-between px-6 py-4 border-b border-border bg-card rounded-t-2xl">
        <button onClick={onPrev} aria-label="Previous month"
          className="p-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-muted transition">
          <ChevronLeft size={18} />
        </button>
        <h2 className="text-lg font-bold text-foreground">
          {MONTH_NAMES[month]} {year}
        </h2>
        <button onClick={onNext} aria-label="Next month"
          className="p-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-muted transition">
          <ChevronRight size={18} />
        </button>
      </div>

      {/* Day headers */}
      <div className="grid grid-cols-7 bg-muted/60 border-b border-border">
        {DAY_NAMES.map((d) => (
          <div key={d} className="py-2 text-center text-xs font-bold uppercase tracking-wider text-muted-foreground">
            {d}
          </div>
        ))}
      </div>

      {/* Day cells */}
      <div className="grid grid-cols-7 flex-1">
        {cells.map((day, idx) => {
          if (!day) return (
            <div key={`empty-${idx}`} className="min-h-[110px] border-b border-r border-border bg-muted/20 last:border-r-0" />
          )

          const dateStr = toLocalDateStr(year, month, day)
          const dayCls = classMap[dateStr] ?? []
          const isToday = dateStr === todayStr

          return (
            <div
              key={dateStr}
              className={`min-h-[110px] border-b border-r border-border last:border-r-0 flex flex-col p-1.5 gap-1 group
                ${isToday ? "bg-brand-light/40" : "bg-card hover:bg-muted/30"}
                transition`}
            >
              {/* Date number */}
              <div className="flex items-start justify-between">
                <span className={`text-sm font-semibold w-7 h-7 flex items-center justify-center rounded-full
                  ${isToday ? "bg-primary text-primary-foreground" : "text-foreground"}`}>
                  {day}
                </span>
                <button
                  onClick={() => onDayClick(dateStr)}
                  aria-label={`Add class on ${dateStr}`}
                  className="opacity-0 group-hover:opacity-100 p-1 rounded-md text-muted-foreground hover:text-primary hover:bg-brand-light transition"
                >
                  <Plus size={13} />
                </button>
              </div>

              {/* Class pills */}
              <div className="flex flex-col gap-1 overflow-hidden">
                {dayCls.slice(0, 3).map((c) => (
                  <button
                    key={c.id}
                    onClick={() => onClassClick(c)}
                    className="text-left text-xs font-medium px-2 py-1 rounded-md bg-primary text-primary-foreground truncate hover:opacity-80 transition leading-snug"
                    title={c.title}
                  >
                    <span className="opacity-80">{c.start_time.slice(0,5)}</span>{" "}{c.title}
                  </button>
                ))}
                {dayCls.length > 3 && (
                  <button
                    onClick={() => onDayClick(dateStr)}
                    className="text-xs text-muted-foreground hover:text-primary px-2"
                  >
                    +{dayCls.length - 3} more
                  </button>
                )}
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}
