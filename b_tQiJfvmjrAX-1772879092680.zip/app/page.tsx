"use client"

import { useState } from "react"
import { GraduationCap, Plus, Loader2, CalendarDays } from "lucide-react"
import CalendarGrid from "@/components/calendar-grid"
import ClassDetailPanel from "@/components/class-detail-panel"
import CreateClassModal from "@/components/create-class-modal"
import UpcomingClasses from "@/components/upcoming-classes"
import { useClasses } from "@/hooks/use-classes"
import type { ClassRow } from "@/lib/db"

export default function HomePage() {
  const now = new Date()
  const [year, setYear] = useState(now.getFullYear())
  const [month, setMonth] = useState(now.getMonth())
  const [selectedClass, setSelectedClass] = useState<ClassRow | null>(null)
  const [createDate, setCreateDate] = useState<string | null>(null)

  const { classes, loading, createClass, updateClass, deleteClass } = useClasses(year, month)

  const handlePrev = () => {
    if (month === 0) { setYear(y => y - 1); setMonth(11) }
    else setMonth(m => m - 1)
  }
  const handleNext = () => {
    if (month === 11) { setYear(y => y + 1); setMonth(0) }
    else setMonth(m => m + 1)
  }

  // Today in YYYY-MM-DD
  const todayStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`

  return (
    <div className="min-h-screen bg-background font-sans">
      {/* Top Nav */}
      <header className="sticky top-0 z-40 border-b border-border bg-card/80 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
          <div className="flex items-center gap-2.5">
            <div className="flex items-center justify-center w-8 h-8 rounded-lg bg-primary">
              <GraduationCap size={16} className="text-primary-foreground" />
            </div>
            <span className="font-bold text-lg text-foreground tracking-tight">LinguaClass</span>
          </div>

          <nav className="hidden sm:flex items-center gap-1">
            <a href="#" className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium text-primary bg-brand-light">
              <CalendarDays size={14} />
              Calendar
            </a>
          </nav>

          <button
            onClick={() => setCreateDate(todayStr)}
            className="flex items-center gap-2 px-4 py-2 rounded-lg bg-primary text-primary-foreground text-sm font-semibold hover:opacity-90 transition shadow-sm"
          >
            <Plus size={15} />
            <span className="hidden sm:inline">New Class</span>
          </button>
        </div>
      </header>

      {/* Main */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 py-8 flex flex-col lg:flex-row gap-8">

        {/* Calendar section */}
        <section className="flex-1 min-w-0">
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-2xl font-bold text-foreground">Class Schedule</h1>
            {loading && <Loader2 size={18} className="animate-spin text-muted-foreground" />}
          </div>

          <div className="rounded-2xl border border-border overflow-hidden shadow-sm bg-card">
            <CalendarGrid
              year={year}
              month={month}
              classes={classes}
              onPrev={handlePrev}
              onNext={handleNext}
              onDayClick={(date) => setCreateDate(date)}
              onClassClick={(cls) => setSelectedClass(cls)}
            />
          </div>

          {/* Legend */}
          <div className="mt-3 flex items-center gap-4 text-xs text-muted-foreground px-1">
            <span className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-full bg-primary inline-block" />
              Scheduled class
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-full bg-brand-light inline-block border border-primary/30" />
              Today
            </span>
            <span className="hidden sm:flex items-center gap-1">
              Hover a day and click <span className="mx-1 inline-flex items-center justify-center w-4 h-4 bg-muted rounded text-foreground"><Plus size={10} /></span> to add a class
            </span>
          </div>
        </section>

        {/* Sidebar */}
        <aside className="w-full lg:w-72 xl:w-80 shrink-0 flex flex-col gap-6">
          {/* Stats */}
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-card border border-border rounded-xl p-4 flex flex-col gap-1">
              <span className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">This Month</span>
              <span className="text-3xl font-bold text-foreground">{classes.length}</span>
              <span className="text-xs text-muted-foreground">classes scheduled</span>
            </div>
            <div className="bg-card border border-border rounded-xl p-4 flex flex-col gap-1">
              <span className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">With Homework</span>
              <span className="text-3xl font-bold text-foreground">{classes.filter(c => c.homework.trim()).length}</span>
              <span className="text-xs text-muted-foreground">assignments set</span>
            </div>
          </div>

          {/* Upcoming */}
          <UpcomingClasses classes={classes} onClassClick={(cls) => setSelectedClass(cls)} />

          {/* Empty state */}
          {!loading && classes.length === 0 && (
            <div className="bg-card border border-dashed border-border rounded-xl p-6 flex flex-col items-center gap-3 text-center">
              <CalendarDays size={28} className="text-muted-foreground" />
              <p className="text-sm text-muted-foreground leading-relaxed">
                No classes this month yet.<br />Click <strong>New Class</strong> or tap a day to get started.
              </p>
            </div>
          )}
        </aside>
      </main>

      {/* Modals */}
      {selectedClass && (
        <ClassDetailPanel
          cls={selectedClass}
          onClose={() => setSelectedClass(null)}
          onUpdate={async (id, payload) => {
            const updated = await updateClass(id, payload)
            setSelectedClass(updated)
            return updated
          }}
          onDelete={async (id) => {
            await deleteClass(id)
            setSelectedClass(null)
          }}
        />
      )}

      {createDate && (
        <CreateClassModal
          date={createDate}
          onCreate={createClass}
          onClose={() => setCreateDate(null)}
        />
      )}
    </div>
  )
}
