import { NextRequest, NextResponse } from "next/server"
import sql from "@/lib/db"

// GET /api/classes?year=2025&month=6
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url)
  const year = parseInt(searchParams.get("year") ?? String(new Date().getFullYear()))
  const month = parseInt(searchParams.get("month") ?? String(new Date().getMonth() + 1))

  const start = `${year}-${String(month).padStart(2, "0")}-01`
  const end   = new Date(year, month, 1).toISOString().slice(0, 10) // first day of next month

  const rows = await sql`
    SELECT * FROM classes
    WHERE date >= ${start} AND date < ${end}
    ORDER BY date ASC, start_time ASC
  `
  return NextResponse.json(rows)
}

// POST /api/classes
export async function POST(req: NextRequest) {
  const body = await req.json()
  const { title, language, teacher, date, start_time, end_time, lesson_notes, homework } = body

  if (!title || !date || !start_time || !end_time) {
    return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
  }

  const [row] = await sql`
    INSERT INTO classes (title, language, teacher, date, start_time, end_time, lesson_notes, homework)
    VALUES (${title}, ${language ?? "English"}, ${teacher ?? "Teacher"}, ${date}, ${start_time}, ${end_time}, ${lesson_notes ?? ""}, ${homework ?? ""})
    RETURNING *
  `
  return NextResponse.json(row, { status: 201 })
}
