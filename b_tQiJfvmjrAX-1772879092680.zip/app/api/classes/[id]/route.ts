import { NextRequest, NextResponse } from "next/server"
import sql from "@/lib/db"

type Params = { params: Promise<{ id: string }> }

// GET /api/classes/:id
export async function GET(_req: NextRequest, { params }: Params) {
  const { id } = await params
  const [row] = await sql`SELECT * FROM classes WHERE id = ${id}`
  if (!row) return NextResponse.json({ error: "Not found" }, { status: 404 })
  return NextResponse.json(row)
}

// PATCH /api/classes/:id
export async function PATCH(req: NextRequest, { params }: Params) {
  const { id } = await params
  const body = await req.json()
  const { title, language, teacher, date, start_time, end_time, lesson_notes, homework } = body

  const [row] = await sql`
    UPDATE classes SET
      title        = COALESCE(${title        ?? null}, title),
      language     = COALESCE(${language     ?? null}, language),
      teacher      = COALESCE(${teacher      ?? null}, teacher),
      date         = COALESCE(${date         ?? null}::date, date),
      start_time   = COALESCE(${start_time   ?? null}::time, start_time),
      end_time     = COALESCE(${end_time     ?? null}::time, end_time),
      lesson_notes = COALESCE(${lesson_notes ?? null}, lesson_notes),
      homework     = COALESCE(${homework     ?? null}, homework),
      updated_at   = NOW()
    WHERE id = ${id}
    RETURNING *
  `
  if (!row) return NextResponse.json({ error: "Not found" }, { status: 404 })
  return NextResponse.json(row)
}

// DELETE /api/classes/:id
export async function DELETE(_req: NextRequest, { params }: Params) {
  const { id } = await params
  await sql`DELETE FROM classes WHERE id = ${id}`
  return NextResponse.json({ success: true })
}
