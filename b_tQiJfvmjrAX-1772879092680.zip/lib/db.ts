import { neon } from "@neondatabase/serverless"

const sql = neon(process.env.DATABASE_URL!)
export default sql

export type ClassRow = {
  id: number
  title: string
  language: string
  teacher: string
  date: string       // YYYY-MM-DD
  start_time: string // HH:MM
  end_time: string   // HH:MM
  lesson_notes: string
  homework: string
  created_at: string
  updated_at: string
}
