-- Language Course: classes table
CREATE TABLE IF NOT EXISTS classes (
  id          SERIAL PRIMARY KEY,
  title       TEXT NOT NULL,
  language    TEXT NOT NULL DEFAULT 'English',
  teacher     TEXT NOT NULL DEFAULT 'Teacher',
  date        DATE NOT NULL,
  start_time  TIME NOT NULL,
  end_time    TIME NOT NULL,
  lesson_notes TEXT NOT NULL DEFAULT '',
  homework    TEXT NOT NULL DEFAULT '',
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Index for fast month-range queries
CREATE INDEX IF NOT EXISTS idx_classes_date ON classes (date);
