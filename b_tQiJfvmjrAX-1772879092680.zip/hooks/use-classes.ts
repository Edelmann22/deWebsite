"use client"

import { useState, useEffect, useCallback } from "react"
import type { ClassRow } from "@/lib/db"

export type { ClassRow }

export function useClasses(year: number, month: number) {
  const [classes, setClasses] = useState<ClassRow[]>([])
  const [loading, setLoading] = useState(true)

  const fetchClasses = useCallback(async () => {
    setLoading(true)
    const res = await fetch(`/api/classes?year=${year}&month=${month}`)
    const data = await res.json()
    setClasses(Array.isArray(data) ? data : [])
    setLoading(false)
  }, [year, month])

  useEffect(() => { fetchClasses() }, [fetchClasses])

  const createClass = async (payload: Omit<ClassRow, "id" | "created_at" | "updated_at">) => {
    const res = await fetch("/api/classes", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    })
    const newClass = await res.json()
    setClasses((prev) => [...prev, newClass].sort((a, b) => a.date.localeCompare(b.date) || a.start_time.localeCompare(b.start_time)))
    return newClass as ClassRow
  }

  const updateClass = async (id: number, payload: Partial<ClassRow>) => {
    const res = await fetch(`/api/classes/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    })
    const updated = await res.json()
    setClasses((prev) => prev.map((c) => (c.id === id ? updated : c)))
    return updated as ClassRow
  }

  const deleteClass = async (id: number) => {
    await fetch(`/api/classes/${id}`, { method: "DELETE" })
    setClasses((prev) => prev.filter((c) => c.id !== id))
  }

  return { classes, loading, refetch: fetchClasses, createClass, updateClass, deleteClass }
}
